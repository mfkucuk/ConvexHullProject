export function clearCanvas(ctx) {
    ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
}